fn main() {
    

    // Using Vec ::new()
    let v : Vec<i64> = Vec::new();

    println!("\nThe length of Vec::new is: {}",v.len());
    
    let v = vec!["Grace","Effiong", "Basil","kareem","Susan"];
    
    println!("\nThe length of vec macro is: { }",v.len());
}
